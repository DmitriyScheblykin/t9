package ru.vsu.cs.scheblykin.cmd;

public class InputArgs {
    public String inputFile;
    public String outputFile;

    public InputArgs(String inputFile, String outputFile) {
        this.inputFile = inputFile;
        this.outputFile = outputFile;
    }
}