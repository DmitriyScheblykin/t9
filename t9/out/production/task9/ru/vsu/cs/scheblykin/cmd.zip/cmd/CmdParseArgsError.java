package ru.vsu.cs.scheblykin.cmd;

public class CmdParseArgsError extends Exception {

}

